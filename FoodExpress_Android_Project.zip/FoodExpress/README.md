# FoodExpress Android Food Delivery App

A simple college-project Android food delivery application built using:

- Kotlin
- XML layouts
- RecyclerView
- Material Components
- Static data
- No database
- Demo payment only

## Demo Login

Name: Any name  
Mobile: 9876543210  
Password: 1234

## Features

1. Login validation
2. Static food menu with 8 items
3. RecyclerView
4. Add to cart
5. Increase/decrease quantity
6. Remove item
7. Automatic subtotal and delivery calculation
8. Demo UPI/card/cash payment
9. Order ID generation
10. Order success screen

## How to run

1. Open the `FoodExpress` folder in Android Studio.
2. Let Gradle sync.
3. Use JDK 11.
4. Run the app on an Android emulator or physical Android phone.
5. Login using the demo credentials above.

## Demo Payment

No real payment gateway is connected. This project simulates payment for academic/demo purposes.
