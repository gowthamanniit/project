package com.example.foodexpress.model

data class FoodItem(
    val id: Int,
    val name: String,
    val description: String,
    val price: Int,
    val emoji: String
)
