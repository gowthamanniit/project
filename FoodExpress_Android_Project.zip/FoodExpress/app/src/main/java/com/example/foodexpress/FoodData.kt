package com.example.foodexpress

import com.example.foodexpress.model.FoodItem

object FoodData {
    val items = listOf(
        FoodItem(1, "Chicken Biriyani", "Delicious chicken biriyani", 180, "🍗"),
        FoodItem(2, "Veg Fried Rice", "Fresh vegetable fried rice", 120, "🍚"),
        FoodItem(3, "Chicken Fried Rice", "Tasty chicken fried rice", 160, "🍗"),
        FoodItem(4, "Masala Dosa", "Crispy South Indian dosa", 80, "🥞"),
        FoodItem(5, "Paneer Pizza", "Cheesy paneer pizza", 220, "🍕"),
        FoodItem(6, "Burger", "Classic delicious burger", 150, "🍔"),
        FoodItem(7, "French Fries", "Crispy golden fries", 100, "🍟"),
        FoodItem(8, "Fresh Lime Juice", "Refreshing lime juice", 60, "🍋")
    )
}
