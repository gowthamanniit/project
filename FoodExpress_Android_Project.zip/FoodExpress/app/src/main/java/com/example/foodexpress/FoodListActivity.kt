package com.example.foodexpress

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.foodexpress.adapter.FoodAdapter
import com.example.foodexpress.databinding.ActivityFoodListBinding

class FoodListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFoodListBinding
    private lateinit var adapter: FoodAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityFoodListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val userName = intent.getStringExtra("USER_NAME") ?: "Customer"
        binding.welcomeText.text = "Welcome, $userName"

        adapter = FoodAdapter(FoodData.items) { food ->
            CartManager.add(food)
            updateCartButton()
            Toast.makeText(this, "${food.name} added to cart", Toast.LENGTH_SHORT).show()
        }

        binding.foodRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.foodRecyclerView.adapter = adapter

        binding.cartButton.setOnClickListener {
            startActivity(Intent(this, CartActivity::class.java))
        }

        updateCartButton()
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized) {
            updateCartButton()
        }
    }

    private fun updateCartButton() {
        binding.cartButton.text = "🛒 Cart (${CartManager.getItemCount()})"
    }
}
