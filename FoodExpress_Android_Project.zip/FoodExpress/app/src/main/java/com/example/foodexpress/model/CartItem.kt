package com.example.foodexpress.model

data class CartItem(
    val food: FoodItem,
    var quantity: Int
)
